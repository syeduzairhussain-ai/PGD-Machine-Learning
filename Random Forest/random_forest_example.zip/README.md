# Random Forest Example

This folder contains:

1. `student_result_data.csv`  
   A simple dataset about students.

2. `random_forest_student_result.py`  
   Python code that trains a Random Forest Classifier.

## How to Run

Install required libraries:

```bash
pip install pandas scikit-learn
```

Run the code:

```bash
python random_forest_student_result.py
```

Make sure both files are in the same folder.
