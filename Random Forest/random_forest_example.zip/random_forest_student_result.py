"""
Random Forest Classification Example
------------------------------------
This program uses a simple dataset to predict whether a student will Pass or Fail.

Dataset file:
student_result_data.csv

Features:
1. study_hours
2. attendance
3. previous_marks
4. assignments_completed

Target:
result
"""

import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report


# Step 1: Load the dataset
data = pd.read_csv("student_result_data.csv")

print("Dataset Preview:")
print(data.head())


# Step 2: Separate input features and output target
X = data[["study_hours", "attendance", "previous_marks", "assignments_completed"]]
y = data["result"]


# Step 3: Split data into training and testing parts
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.25,
    random_state=42
)


# Step 4: Create the Random Forest model
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)


# Step 5: Train the model
model.fit(X_train, y_train)


# Step 6: Make predictions on test data
y_pred = model.predict(X_test)


# Step 7: Check model performance
print("\nAccuracy:", accuracy_score(y_test, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("\nClassification Report:")
print(classification_report(y_test, y_pred))


# Step 8: Predict result for a new student
new_student = pd.DataFrame({
    "study_hours": [6],
    "attendance": [75],
    "previous_marks": [65],
    "assignments_completed": [6]
})

prediction = model.predict(new_student)

print("\nNew Student Data:")
print(new_student)

print("\nPredicted Result:", prediction[0])


# Step 9: Show feature importance
importance = pd.DataFrame({
    "Feature": X.columns,
    "Importance": model.feature_importances_
})

importance = importance.sort_values(by="Importance", ascending=False)

print("\nFeature Importance:")
print(importance)
